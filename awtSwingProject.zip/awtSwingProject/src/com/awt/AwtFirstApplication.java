package com.awt;

import java.awt.Button;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

public class AwtFirstApplication extends JFrame implements ActionListener{

	Button red, green, blue, black;
	// will set these using constructor
	
	public AwtFirstApplication() {
		red = new Button("red");
		green = new Button("green");
		blue = new Button("blue");
		black = new Button("black");
		
		// also set layout
		setLayout(new FlowLayout());
		
		//pass value
		red.addActionListener(this);
		green.addActionListener(this);
		blue.addActionListener(this);
		black.addActionListener(this);
		
		add(red);
		add(green);
		add(blue);
		add(black);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AwtFirstApplication frame = new AwtFirstApplication();
		frame.setTitle("Awt Swing Application");
		frame.setSize(400, 300);
		frame.setVisible(true);
		

	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("red")) {
			getContentPane().setBackground(Color.RED);
		} else if (e.getActionCommand().equals("blue"))  {
			getContentPane().setBackground(Color.BLUE);
		} else if (e.getActionCommand().equals("black")) {
			getContentPane().setBackground(Color.black); 
		} else if (e.getActionCommand().equals("green")) {
			getContentPane().setBackground(Color.green);	
		}	
	}	
}

