package com.awt;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;

import javax.swing.Action;
import javax.swing.JFrame;

public class Calculator extends JFrame implements Action{

	TextField val1, val2, result;
	Button addBtn, subBtn, divBtn, mulBtn, modBtn;
	
	public Calculator() {
		val1 = new TextField(10);
		val2 = new TextField(10);
		result = new TextField(40);
		
		result.setEditable(false);
		
		addBtn = new Button("Add");
		subBtn = new Button("Subtract");
		mulBtn = new Button("Multiply");
		divBtn = new Button("Divide");
		modBtn = new Button ("Modulus");
		
		setLayout(new FlowLayout());
		
		add(new Label("First Number: "));
		add(val1);
		add(new Label("Second Number: "));
		add(val2);
		add(new Label("Operator: "));
		add(addBtn);
		add(subBtn);
		add(mulBtn);
		add(divBtn);
		add(modBtn);
		
		add(new Label("Result: "));
		add(result);
		
		addBtn.addActionListener(this);
		subBtn.addActionListener(this);
		mulBtn.addActionListener(this);
		divBtn.addActionListener(this);
		modBtn.addActionListener(this);
	}
	
	public static void main(String[] args) {
		Calculator f = new Calculator();
		f.setTitle("cal");
		f.setSize(700, 200);
		f.setVisible(true);
		
		

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		32
		try {
			int num1 = Integer.parseInt(val1.getText());
			int num2 = Integer.parseInt(val2.getText());
			
			if(arg0.getSource() == addBtn) {
				result.setText("Sum: " + (num1 + num2));
			} else if (arg0.getSource() == subBtn) {
				result.setText("Diff: " + (num1-num2));
			} else if (arg0.getSource() == mulBtn) {
				result.setText("product: " + (num1*num2));
			} else if (arg0.getSource() == divBtn) {
				result.setText("div: " + (num1/num2));
			} else if (arg0.getSource() == modBtn) {
				result.setText("mod: " + (num1%num2));
			}
		} catch(Exception e2) {
			result.setText("Error: " + e2.getLocalizedMessage());
	}
//
//	@Override
//	public Object getValue(String arg0) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public void putValue(String arg0, Object arg1) {
//		// TODO Auto-generated method stub
		
	}

}
