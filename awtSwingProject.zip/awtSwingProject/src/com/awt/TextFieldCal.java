//package com.awt;
//
//import java.awt.Button;
//import java.awt.FlowLayout;
//import java.awt.Label;
//import java.awt.TextField;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//import javax.swing.JFrame;
//
//// class ko extend Interface ko implement
//public class TextFieldCal extends JFrame implements ActionListener{
//
//	TextField t1, t2, result;
//	
//	Button addBtn, subBtn;
//	
//	//constructor
//	public TextFieldCal() {
//		
//		
//		t1 = new TextField(10);
//		t2 = new TextField(10);
//		result = new TextField(15);
//		result.setEditable(false);
//		
//		addBtn = new Button("Add");
//		subBtn = new Button("Subtract");
//		
//		setLayout(new FlowLayout());
//		
//		add(new Label("First Number: "));
//		add(t1);
//		add(new Label("Second Number: "));
//		add(t2);
//		add(addBtn);
//		add(subBtn);
//		add(new Label("Result: "));
//		add(result);
//		
//		addBtn.addActionListener(this);
//		subBtn.addActionListener(this);
//	}
//	
//	
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		//select of awt
//		new TextFieldCal();
//	}
//
//	@Override
//	public void actionPerformed(ActionEvent arg0) {
//		try {
//			int num1 = Integer.parseInt(t1.getText());
//			int num2 = Integer.parseInt(t2.getText());
//			
//			if(arg0.getSource() == addBtn) {
//				result.setText("Sub : " + (num1 + num2));
//			} else if(arg0.getSource() == subBtn) {
//				result.setText("Diff : " + (num1 - num2));
//			}
//			
//		} catch (Exception e) {
//			
//		}
//		
//	}
//
//}


package com.awt;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

public class TextFieldCal extends JFrame implements ActionListener {

	TextField t1, t2, result;
	Button addBtn, subBtn;

	public TextFieldCal() {
		t1 = new TextField(10);
		t2 = new TextField(10);
		result = new TextField(15);
		result.setEditable(false);

		addBtn = new Button("Add");
		subBtn = new Button("Subtract");

		setLayout(new FlowLayout());

		add(new Label("First Number : "));
		add(t1);
		add(new Label("Second Number : "));
		add(t2);
		add(addBtn);
		add(subBtn);
		add(new Label("Result :"));
		add(result);

		addBtn.addActionListener(this);
		subBtn.addActionListener(this);

	}

	public static void main(String[] args) {
		TextFieldCal frame	=new TextFieldCal();
		frame.setTitle("Cal");
		frame.setSize(400, 300);
		frame.setVisible(true);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		try {

			int num1 = Integer.parseInt(t1.getText());
			int num2 = Integer.parseInt(t2.getText());

			if (e.getSource() == addBtn) {
				result.setText("Sum : " + (num1 + num2));
			} else if (e.getSource() == subBtn) {
				result.setText("Diff : " + (num1 - num2));
			}

		} catch (Exception e2) {

		}

	}

}