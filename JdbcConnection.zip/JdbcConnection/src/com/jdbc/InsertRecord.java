package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertRecord {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/arya", "ayush", "Ayush@123");
		Statement stmt=con.createStatement();
		String str="insert into student values(10,'Chandan',25)";
		stmt.executeUpdate(str);
		System.out.println("insert record success");
	}

}
