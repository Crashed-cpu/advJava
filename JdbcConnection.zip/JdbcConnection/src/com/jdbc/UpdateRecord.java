package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdateRecord {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/arya", "ayush", "Ayush@123");
		Statement stmt=con.createStatement();
		String str="select * from student";
		ResultSet rs=stmt.executeQuery(str);
		
		while(rs.next()) {
			System.out.println("Student Id : "+rs.getInt("stdid"));
			System.out.println("Student Name : "+rs.getString("stdname"));
			System.out.println("Student roll no : "+rs.getInt("stdrollno"));
		}
		
		System.out.println("select record success");
	}

}
