package com.first;

public class FirstServlet implements Servle {
	// right click -> init method service method and destroy method
	
}
