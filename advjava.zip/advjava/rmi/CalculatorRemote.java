import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class CalculatorRemote extends UnicastRemoteObject implements Calculator {

	CalculatorRemote() throws RemoteException {
		super();
	}

	@Override
	public String add( double x, double y ) throws RemoteException {
		String result;
		result = "Sum: "+(x+y);
		return result;
	}

	@Override
	public String sub(double x, double y) throws RemoteException {
		String result;
		result = "Sub: "+(x-y);
		return result;
	}

	@Override
		public String sub(double x, double y) throws RemoteException {
			String result;
			result = "Mult: "+(x*y);
			return result;
		}

	@Override
	public String sub(double x, double y) throws RemoteException {
		String result;
		result = "Div: "+(x/y);
		return result;
	}
}