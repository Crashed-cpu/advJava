public class noinno {

	public static void main(String a[]) {
		int num = 1233464543;
		int n = 6, x = num, rem;
		int[] count = new int[10];
		// System.out.println("Which number do you want to get the count of");
		
		while (x != 0) {
			rem = x % 10;
			count[rem]++;
			x = x / 10;
		}
		System.out.println("Occurance of number "+ n + " is: " + count[n]);
	}
}
